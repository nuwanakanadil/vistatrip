/**
 * 
 */

document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form");
    form.addEventListener("submit", function (event) {
        if (!validateForm()) {
            event.preventDefault(); // Prevent form submission
        }
    });
})

function validateForm() {
	
	const username = document.getElementById("username").value.trim();
	const password = document.getElementById("password").value;
	
	const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d\W_]{8,}$/; // At least 8 characters, one letter, one number, and any special character
	
	// Validation checks
	   if (!username || !password) {
	       alert("❌ Please fill out all fields.");
	       return false;
	   }
	   if (!passwordPattern.test(password)) {
	           alert("❌ Password must be at least 8 characters long and include at least one letter and one number.");
	           return false;
	   }
	   
	   return true
	   
}

