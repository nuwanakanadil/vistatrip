/**
 * 
 */
document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form");
    form.addEventListener("submit", function (event) {
        if (!validateForm()) {
            event.preventDefault(); // Prevent form submission
        }
    });
})
function validateForm() {
    // Get form field values
    const username = document.getElementById("username").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("re-enterpassword").value;

    // Regular expressions for validation
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d\W_]{8,}$/; // At least 8 characters, one letter, one number, and any special character

    // Validation checks
    if ( !username || !email || !password || !confirmPassword) {
        alert("❌ Please fill out all fields.");
        return false;
    }

    if (!emailPattern.test(email)) {
        alert("❌ Invalid email format. Please enter a valid email address.");
        return false;
    }


    if (!passwordPattern.test(password)) {
        alert("❌ Password must be at least 8 characters long and include at least one letter and one number.");
        return false;
    }

    if (password !== confirmPassword) {
        alert("❌ Passwords do not match. Please check and try again.");
        return false;
    }

    // If all checks pass
    return true;
}