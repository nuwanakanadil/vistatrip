/**
 * 
 */
const imageInput = document.getElementById('images');
const previewContainer = document.getElementById('preview-container');
let selectedFiles = [];

imageInput.addEventListener('change', (event) => {
  const files = Array.from(event.target.files);

  selectedFiles = selectedFiles.concat(files);
  displayPreviews();
});

function displayPreviews() {
  previewContainer.innerHTML = '';

  selectedFiles.forEach((file, index) => {
    const reader = new FileReader();
    reader.onload = () => {
      const previewBox = document.createElement('div');
      previewBox.className = 'preview-box';

      const img = document.createElement('img');
      img.src = reader.result;

      const removeBtn = document.createElement('button');
      removeBtn.className = 'remove-btn';
      removeBtn.innerHTML = '&times;';
      removeBtn.addEventListener('click', () => {
        selectedFiles.splice(index, 1);
        displayPreviews();
      });

      previewBox.appendChild(img);
      previewBox.appendChild(removeBtn);
      previewContainer.appendChild(previewBox);
    };
    reader.readAsDataURL(file);
  });
}

function openModal() {
  document.getElementById('modalOverlay').classList.remove('hidden');
}

function closeModal() {
  document.getElementById('modalOverlay').classList.add('hidden');
}


function openEditModal(button) {
  console.log("openEditModal called", button);
  const row = button.closest('tr');
  const cells = row.querySelectorAll('td');

  const title = cells[1].textContent.trim();
  const location = cells[2].textContent.trim();
  const guide = cells[3].textContent.trim();
  const price = cells[4].textContent.trim();
  const description = cells[5].textContent.trim();

  document.getElementById('title').value = title;
  document.getElementById('location').value = location;

  const guideSelect = document.getElementById('guide');
  let found = false;
  for (let i = 0; i < guideSelect.options.length; i++) {
    const option = guideSelect.options[i];
    if (
      option.text.trim().toLowerCase() === guide.toLowerCase() ||
      option.value.trim().toLowerCase() === guide.toLowerCase()
    ) {
      guideSelect.selectedIndex = i;
      found = true;
      break;
    }
  }
  if (!found) {
    guideSelect.selectedIndex = 0;
  }

  document.getElementById('price').value = price;
  document.getElementById('description').value = description;

  // Don't try to set .value for file inputs
  // document.getElementById('images').value = images;

  document.getElementById('form-title').innerHTML = "Edit Tour Package";
  document.getElementById('tour-btn').innerHTML = "Save";

  document.getElementById('modalOverlay').classList.remove('hidden');
}

