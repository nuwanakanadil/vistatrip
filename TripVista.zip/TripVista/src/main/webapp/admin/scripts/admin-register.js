/**
 * 
 */
const imageInput = document.getElementById('fileName');
const previewContainer = document.getElementById('preview-container');
let selectedFiles = [];
	
imageInput.addEventListener('change', (event) => {
	const file = event.target.files[0];
	if (file) {
	   selectedFiles = [file]; // Only store one image
	   displayPreviews();
	}
});
	
 function displayPreviews() {
	previewContainer.innerHTML = '';
	
	selectedFiles.forEach((file, index) => {
	   const reader = new FileReader();
	   reader.onload = () => {
	       const previewBox = document.createElement('div');
	       previewBox.className = 'preview-box';
	
	       const img = document.createElement('img');
	       img.src = reader.result;
	
	       const removeBtn = document.createElement('button');
	       removeBtn.className = 'remove-btn';
	       removeBtn.innerHTML = '&times;';
	       removeBtn.addEventListener('click', () => {
	          selectedFiles = [];
	          imageInput.value = ''; // Clear the input field
	          displayPreviews();
	     });
	
	     previewBox.appendChild(img);
	     previewBox.appendChild(removeBtn);
	     previewContainer.appendChild(previewBox);
	};
	reader.readAsDataURL(file);
	});
}