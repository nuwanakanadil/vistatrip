
const imageInput = document.getElementById('fileName');
const previewContainer = document.getElementById('preview-container');
let selectedFiles = [];

imageInput.addEventListener('change', (event) => {
  const file = event.target.files[0];
  if (file) {
    selectedFiles = [file]; // Only store one image
    displayPreviews();
  }
});

function displayPreviews() {
  previewContainer.innerHTML = '';

  selectedFiles.forEach((file, index) => {
    const reader = new FileReader();
    reader.onload = () => {
      const previewBox = document.createElement('div');
      previewBox.className = 'preview-box';

      const img = document.createElement('img');
      img.src = reader.result;

      const removeBtn = document.createElement('button');
      removeBtn.className = 'remove-btn';
	  removeBtn.type = 'button';
      removeBtn.innerHTML = '&times;';
      removeBtn.addEventListener('click', () => {
        selectedFiles = [];
        imageInput.value = ''; // Clear the input field
        displayPreviews();
      });

      previewBox.appendChild(img);
      previewBox.appendChild(removeBtn);
      previewContainer.appendChild(previewBox);
    };
    reader.readAsDataURL(file);
  });
}

function openModal() {
    document.getElementById('adminModal').classList.remove('hidden');
}

function closeModal() {
    document.getElementById('adminModal').classList.add('hidden');
}

function openEditModal(button) {
    const row = button.closest('tr');
	
	// Access the username and password from the data-* attributes
	const username = row.dataset.username;
	const password = row.dataset.password;
	
	document.getElementById('username').value = username;
	document.getElementById('password').value = password;
	
	
    const cells = row.querySelectorAll('td');

    const name = cells[1].textContent.trim();
	
    const imageSrc = cells[2].querySelector('img').getAttribute('src');
    const email = cells[3].textContent.trim();
    const role = cells[4].textContent.trim();

    // Populate the form fields
    document.getElementById('name').value = name;
    document.getElementById('email').value = email;

    // Set the correct role option
    const roleSelect = document.getElementById('role');
    let found = false;
    for (let i = 0; i < roleSelect.options.length; i++) {
        const option = roleSelect.options[i];
        if (
            option.text.trim().toLowerCase() === role.toLowerCase() ||
            option.value.trim().toLowerCase() === role.toLowerCase()
        ) {
            roleSelect.selectedIndex = i;
            found = true;
            break;
        }
    }

    if (!found) {
        roleSelect.selectedIndex = 0; // fallback to "Select Role"
    }

    // Set the admin ID for editing
    const adminId = cells[0].textContent.trim(); // Assuming ID is in the first cell
    document.getElementById('adminId').value = adminId;

    // Show the image in the preview
    selectedFiles = []; // Clear selected files if any
    previewContainer.innerHTML = ''; // Clear old previews

    const previewBox = document.createElement('div');
    previewBox.className = 'preview-box';

    const img = document.createElement('img');
    img.src = imageSrc;

    const removeBtn = document.createElement('button');
    removeBtn.className = 'remove-btn';
    removeBtn.innerHTML = '&times;';
    removeBtn.addEventListener('click', () => {
        selectedFiles = [];
        imageInput.value = ''; // Clear file input
        previewContainer.innerHTML = '';
    });

    previewBox.appendChild(img);
    previewBox.appendChild(removeBtn);
    previewContainer.appendChild(previewBox);

    // Update the form for editing
    document.getElementById('form-title').innerHTML = "Edit Admin Details";
    document.getElementById('admin-btn').innerHTML = "Save Changes";

    // Show the modal
    document.getElementById('adminModal').classList.remove('hidden');
    
    // Set the action to 'edit' for updating
    document.getElementById('action').value = "update";
	
	// Hide the username and password fields when editing
	document.getElementById('username-group').style.display = 'none';
	document.getElementById('password-group').style.display = 'none';
}

function searchById() {
    const id = document.getElementById('searchId2').value.trim();

	if (id === "") {
	   alert("Please enter an Admin ID to search.");
	   return;
	}

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'admin?action=searchById', true); // Your servlet URL
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');  // Set the correct content type

    // Set up the response handler
    xhr.onload = function () {
        if (xhr.status === 200) {
            // Get the table header and the response data (body)
            const tableHeader = document.getElementById('adminTableHeader').outerHTML;
            const tableBody = xhr.responseText;

            // Update the entire table with the header and body
            document.getElementById('adminTable').innerHTML = tableHeader + tableBody;
        } else {
            console.error("Error: " + xhr.status);  // Handle non-200 status codes
            showToast("Error fetching admin data.");
        }
    };

    // Send the data (id) to the servlet
    xhr.send('id=' + encodeURIComponent(id));
}


function resetTable() {
    window.location.href = 'admin'; // reloads full list
}

