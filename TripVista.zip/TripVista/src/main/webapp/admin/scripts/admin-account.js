/**
 * 
 */
const editBtn = document.getElementById("editBtn");
const modal = document.getElementById("picModal");
const closeModal = document.getElementById("closeModal");
const uploadCircle = document.getElementById("uploadCircle");
const fileInput = document.getElementById("newPicInput");
const previewPic = document.getElementById("previewPic");
const currentProfilePic = document.getElementById("currentProfilePic");
const savePicBtn = document.getElementById("savePicBtn");

// Open modal
editBtn.addEventListener("click", () => {
  modal.style.display = "flex";
});

// Close modal
closeModal.addEventListener("click", () => {
  modal.style.display = "none";
});

// Trigger file input
uploadCircle.addEventListener("click", () => {
  fileInput.click();
});

// Show image preview
fileInput.addEventListener("change", function () {
  const file = this.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function (e) {
      previewPic.src = e.target.result;
      previewPic.style.display = "block";
    };
    reader.readAsDataURL(file);
  }
});

// Save new image
savePicBtn.addEventListener("click", () => {
  const selectedFile = fileInput.files[0];
  console.log('Selected File:', selectedFile);

  if (selectedFile) {
    const reader = new FileReader();
    reader.onload = function (e) {
      currentProfilePic.src = e.target.result;
      console.log('Image preview set:', e.target.result);
    };
    reader.readAsDataURL(selectedFile);

    const actualInput = document.getElementById("profile-image-input");
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(selectedFile);
    actualInput.files = dataTransfer.files;
    console.log('File input updated:', actualInput.files);
  }

  modal.style.display = "none";
});


document.addEventListener('DOMContentLoaded', () => {
  const navLinks = document.querySelectorAll('.nav-list a');
  const sections = {
    'account-details': document.getElementById('account-details'),
    'change-password': document.getElementById('change-password'),
  };

  // Initially show only account details
  for (let key in sections) {
    sections[key].style.display = 'none';
  }
  sections['account-details'].style.display = 'block';

  navLinks.forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();

      // Remove 'active' class from all links
      navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');

      // Hide all sections
      for (let key in sections) {
        sections[key].style.display = 'none';
      }

      // Show the selected section
      const targetId = link.getAttribute('href').substring(1); // remove #
      if (sections[targetId]) {
        sections[targetId].style.display = 'block';
      }
    });
  });
});

