package com.tripvista.service;

import com.tripvista.modal.TourPackage;
import com.tripvista.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TourPackageService {

    // Create Tour Package with Images
    public boolean createTourPackage(TourPackage tour, List<String> imageFileNames) {
        String query = "INSERT INTO tour_package (title, destination, guide, price, description, file_name) VALUES (?, ?, ?, ?, ?, ?)";
        String imageQuery = "INSERT INTO tour_images (package_id, file_name) VALUES (?, ?)";

        try (Connection connection = DBConnection.getConnection()) {
            connection.setAutoCommit(false); // Start transaction

            // Insert tour_package
            try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, tour.getTitle());
                stmt.setString(2, tour.getDestination());
                stmt.setString(3, tour.getGuide());
                stmt.setDouble(4, tour.getPrice());
                stmt.setString(5, tour.getDescription());
                stmt.setString(6, tour.getFileName());

                int affectedRows = stmt.executeUpdate();
                if (affectedRows == 0) throw new SQLException("Creating tour package failed.");

                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int tourId = generatedKeys.getInt(1);

                    // Insert images
                    try (PreparedStatement imageStmt = connection.prepareStatement(imageQuery)) {
                        for (String fileName : imageFileNames) {
                            imageStmt.setInt(1, tourId);
                            imageStmt.setString(2, fileName);
                            imageStmt.addBatch();
                        }
                        imageStmt.executeBatch();
                    }
                }
            }

            connection.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Get Tour Package with basic info only
    public TourPackage getTourPackage(int id) {
        String query = "SELECT * FROM tour_package WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                TourPackage tour = mapResultSetToTour(rs);
                tour.setImages(getImagesForPackage(id)); // Load images
                return tour;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Get All Tour Packages
    public List<TourPackage> getAllTourPackages() {
        List<TourPackage> tourPackages = new ArrayList<>();
        String query = "SELECT * FROM tour_package";
        try (Connection connection = DBConnection.getConnection();
             Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                TourPackage tour = mapResultSetToTour(rs);
                tour.setImages(getImagesForPackage(tour.getId()));
                tourPackages.add(tour);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tourPackages;
    }

    // Get images for a package
    public List<String> getImagesForPackage(int packageId) {
        List<String> images = new ArrayList<>();
        String query = "SELECT file_name FROM tour_images WHERE package_id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, packageId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                images.add(rs.getString("file_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return images;
    }

    // Update Tour Package (does not update images here)
    public boolean updateTourPackage(TourPackage tour) {
        String query = "UPDATE tour_package SET title = ?, destination = ?, guide = ?, price = ?, description = ?, file_name = ? WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, tour.getTitle());
            stmt.setString(2, tour.getDestination());
            stmt.setString(3, tour.getGuide());
            stmt.setDouble(4, tour.getPrice());
            stmt.setString(5, tour.getDescription());
            stmt.setString(6, tour.getFileName());
            stmt.setInt(7, tour.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete Tour Package (images are deleted via ON DELETE CASCADE)
    public boolean deleteTourPackage(int id) {
        String query = "DELETE FROM tour_package WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Utility: Convert ResultSet to TourPackage object
    private TourPackage mapResultSetToTour(ResultSet rs) throws SQLException {
        TourPackage tour = new TourPackage();
        tour.setId(rs.getInt("id"));
        tour.setTitle(rs.getString("title"));
        tour.setDestination(rs.getString("destination"));
        tour.setGuide(rs.getString("guide"));
        tour.setPrice(rs.getDouble("price"));
        tour.setDescription(rs.getString("description"));
        tour.setFileName(rs.getString("file_name"));
        return tour;
    }
}
