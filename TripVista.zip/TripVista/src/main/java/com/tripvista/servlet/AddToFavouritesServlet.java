package com.tripvista.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tripvista.modal.Tourist;
import com.tripvista.util.FavouritesDBUtil;


/**
 * The AddToFavouritesServlet class handles the process of adding a tour package to the logged-in user's favourites.
 * It retrieves the package ID from the request parameter, checks if the user is logged in, and adds the package to their favourites.
 * If the user is not logged in, it redirects them to the login page.
 */

@WebServlet("/AddToFavouritesServlet")
public class AddToFavouritesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		 try {
	            int packageId = Integer.parseInt(request.getParameter("packageId")); // Retrieve the package ID from the request parameter

	            HttpSession session = request.getSession(); // Get current HTTP session
	       
	         // Retrieve logged-in user details from session
	            Tourist user = (session != null) ? (Tourist) session.getAttribute("userDetails") : null;
	            int userId = user.getTid();  // Get user ID from the tourist object
	            
	            if (user != null) {
	            	
	            	// Create FavouritesDBUtil object and call method to add package to favourites
	                FavouritesDBUtil favUtil = new FavouritesDBUtil(); 
	                favUtil.addToFavourites(userId, packageId);

	                // Redirect to homepage with success status
	                response.sendRedirect("HomeServlet?status=success");
	            } else {
	            	
	                // If user is not logged in
	                response.sendRedirect("login.jsp");
	            }

	        } catch (Exception e) { // Handle exceptions and redirect with failure status

	            e.printStackTrace();
	            response.sendRedirect("HomeServlet?status=fail");
	        }
	    
	}

}
