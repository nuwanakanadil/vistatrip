package com.tripvista.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tripvista.modal.Tourist;

/**
 * Servlet implementation class DeleteAccountServlet
 */
@WebServlet("/DeleteAccountServlet")
public class DeleteAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//Check user logged in or not
		HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            // Not logged in
        	// create a new session to store message
            session = request.getSession(); 
            session.setAttribute("errorMessage", "You must be logged in to delete your account.");
            response.sendRedirect("login.jsp");
            return;
        }
		
     // Get username and password from the form
		String userName = request.getParameter("userName");
        String password = request.getParameter("password");
        
     // Create a Tourist object with the provided credentials
        Tourist tourist = new Tourist(0, null, null, userName, null, null, null, password);
 
     // call delete method using the Tourist object
        boolean isDeleted = tourist.delete();
        
        if (isDeleted) {
        	 // Invalidate session to log out user
            session.invalidate();

            // Create a new session to store message (since session was invalidated)
            HttpSession newSession = request.getSession(true);
            newSession.setAttribute("successMessage", "Your account was deleted successfully. You have been logged out.");
            response.sendRedirect("signup.jsp");
            
        } else {
        	// If deletion fails, set an error message in the session
        	session.setAttribute("errorMessage", "Invalid username or password. Account deletion failed.");
            response.sendRedirect("deleteAccount.jsp");
        }

       
    }
	}
