package com.tripvista.servlet;

import com.tripvista.modal.Admin;
import com.tripvista.service.AdminService;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.List;

@WebServlet(urlPatterns = {"/admin", "/admin/"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
        maxFileSize = 1024 * 1024 * 10, // 10MB
        maxRequestSize = 1024 * 1024 * 50) // 50MB
public class AdminServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private AdminService adminService;

    @Override
    public void init() throws ServletException {
        super.init();
        adminService = new AdminService();
    }

    private String handlePhotoUpload(Part filePart, String uploadDirectory) throws IOException {
        if (filePart != null && filePart.getSize() > 0) {
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            String uploadPath = getServletContext().getRealPath("") + File.separator + uploadDirectory;

            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            String filePath = uploadPath + File.separator + fileName;
            filePart.write(filePath);

            return fileName;
        }
        return null;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        AdminService service = new AdminService();
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("admin") == null) {
        	System.out.println("Session is null or admin not in session — redirecting to login.");
            response.sendRedirect(request.getContextPath() + "/admin/login");
            return;
        }
        
        request.setAttribute("adminName", session.getAttribute("name"));
        request.setAttribute("adminUsername", session.getAttribute("username"));
        request.setAttribute("adminEmail", session.getAttribute("email"));
        request.setAttribute("adminRole", session.getAttribute("role"));
        request.setAttribute("fileName", session.getAttribute("fileName"));
        
        if (action == null) {
            List<Admin> admins = service.getAllAdmins();
            request.setAttribute("admins", admins); // adminList is List<Admin>
            request.getRequestDispatcher("/admin/admin-manage.jsp").forward(request, response);
        } else if (action.equals("view")) {
            int id = Integer.parseInt(request.getParameter("id"));
            Admin admin = adminService.getAdmin(id);
            request.setAttribute("admin", admin);
            request.getRequestDispatcher("admin/manageAdminsIndex.jsp").forward(request, response);
        } else if (action.equals("edit")) {
            int id = Integer.parseInt(request.getParameter("id"));
            Admin admin = adminService.getAdmin(id);
            request.setAttribute("admin", admin);
            request.getRequestDispatcher("/admin/admin-account.jsp").forward(request, response);
        } else if (action.equals("delete")) {
            int id = Integer.parseInt(request.getParameter("id"));
            adminService.deleteAdmin(id);
            response.sendRedirect("admin");
        } else if (action.equals("logout")) {
            session.invalidate();
            response.sendRedirect(request.getContextPath() + "/admin/login");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        AdminService service = new AdminService();

        if (action.equals("create")) {
            String name = request.getParameter("name");
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String email = request.getParameter("email");
            String role = request.getParameter("role");
            Part picturePart = request.getPart("fileName");

            String fileName = handlePhotoUpload(picturePart, "admin/images/pictures");
            

            Admin admin = new Admin();
            admin.setName(name);
            admin.setUsername(username);
            admin.setPassword(password);
            admin.setEmail(email);
            admin.setRole(role);
            admin.setFileName(fileName);

            if (adminService.createAdmin(admin)) {
                response.sendRedirect("admin");
            } else {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }
        } else if (action.equals("update")) {
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String email = request.getParameter("email");
            String role = request.getParameter("role");
            Part picturePart = request.getPart("fileName");

            String fileName = handlePhotoUpload(picturePart, "admin/images/pictures");
            Admin existingAdmin = service.getAdminById(id);

            Admin admin = new Admin();
            admin.setId(id);
            admin.setName(name);
            admin.setUsername(username != null ? username : existingAdmin.getUsername());
            
            // Only update password if a new one is provided
            if (password != null && !password.trim().isEmpty()) {
                admin.setPassword(password);
            } else {
                admin.setPassword(existingAdmin.getPassword()); // Keep current password
            }
            
            admin.setEmail(email);
            admin.setRole(role);

            if (fileName != null) {
                admin.setFileName(fileName);
            }

            if (adminService.updateAdmin(admin)) {
                response.sendRedirect("admin");
            } else {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }
        } else if (action.equals("delete")) {
            int id = Integer.parseInt(request.getParameter("id"));
            if (adminService.deleteAdmin(id)) {
                response.sendRedirect("admin");
            } else {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }
        } else if (action.equals("searchById")) {
            String idParam = request.getParameter("id");
            if (idParam != null && !idParam.trim().isEmpty()) {
                int id = Integer.parseInt(idParam);
                Admin admin = adminService.getAdminById(id);

                response.setContentType("text/html");
                PrintWriter out = response.getWriter();

                if (admin != null) {
                    out.println("<tr>");
                    out.println("<td>" + admin.getId() + "</td>");
                    out.println("<td>" + admin.getName() + "</td>");
                    out.println("<td><img src='admin/images/pictures/" + admin.getFileName() + "'></td>");
                    out.println("<td>" + admin.getEmail() + "</td>");
                    out.println("<td>" + admin.getRole() + "</td>");
                    out.println("<td class='text-center'>");
                    out.println("<button onclick=\"openEditModal(this)\" class=\"updateBtn\"><i class=\"fas fa-edit\"></i></button>");
                    out.println("<button class=\"removeBtn\" onclick=\"confirmAction('admin?action=delete&id=" + admin.getId() + "')\"><i class=\"fas fa-trash\"></i></button>");
                    out.println("</td>");
                    out.println("</tr>");
                } else {
                    out.println("<tr><td colspan='6'>No admin found with the provided ID.</td></tr>");
                }
            }
            return;
        } else if (action.equals("updateAccountDetails")) {
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String username = request.getParameter("username");
            String email = request.getParameter("email");
            Part picturePart = request.getPart("fileName");
            
            // Fetch existing admin details
            Admin existingAdmin = service.getAdminById(id);

            // Handle picture upload (only if a new file is uploaded)
            String fileName = null;
            if (picturePart != null && picturePart.getSize() > 0) {
                fileName = handlePhotoUpload(picturePart, "admin/images/pictures");
            }

            Admin admin = new Admin();
            admin.setId(id);
            admin.setName(name != null ? name.trim() : existingAdmin.getName());
            admin.setUsername((username != null && !username.trim().isEmpty()) ? username.trim() : existingAdmin.getUsername());
            admin.setEmail((email != null && !email.trim().isEmpty()) ? email.trim() : existingAdmin.getEmail());
            admin.setFileName((fileName != null) ? fileName : existingAdmin.getFileName());

            // Update admin info
            boolean updated = adminService.updateAdminProfile(admin);

            if (updated) {
            	HttpSession session = request.getSession();
                session.setAttribute("id", admin.getId());
                session.setAttribute("name", admin.getName());
                session.setAttribute("username", admin.getUsername());
                session.setAttribute("email", admin.getEmail());
                session.setAttribute("file_name", admin.getFileName());

                response.sendRedirect(request.getContextPath() + "/admin/admin-account.jsp");
            } else {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to update account details.");
            }
        } else if (action.equals("updatePassword")) {
            int id = Integer.parseInt(request.getParameter("id"));
            String currentPassword = request.getParameter("currentPassword");
            String newPassword = request.getParameter("newPassword");
            String confirmPassword = request.getParameter("confirmPassword");

            Admin admin = adminService.getAdminById(id);

            // Validate if the current password matches the one in the database
            if (admin != null && admin.getPassword().equals(currentPassword)) {
                // Ensure the new password and confirm password match
                if (newPassword.equals(confirmPassword)) {
                    admin.setPassword(newPassword);  // Set the new password

                    if (adminService.updateAdminPassword(admin)) {
                        response.sendRedirect("admin");  // Redirect to admin list page
                    } else {
                        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    }
                } else {
                    // New password and confirm password don't match
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Passwords do not match.");
                }
            } else {
                // Invalid current password
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Current password is incorrect.");
            }
        }
    }
}
