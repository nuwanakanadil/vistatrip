package com.tripvista.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tripvista.util.FavouritesDBUtil;

import com.tripvista.modal.TourPackage;
import com.tripvista.modal.Tourist;

/**
 * The FavouritesServlet class handles the request for displaying a user's favourite tour packages.
 * It retrieves the list of favourite packages for a logged-in user and forwards the data to a JSP page for display.
 * If the user is not logged in, they are redirected to the login page.
 */
@WebServlet("/FavouritesServlet")
public class FavouritesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		  
		// Retrieve existing session, don't create a new one if it doesn't exist
		 	HttpSession session = request.getSession(false);
		 	
		 // Get user details from session
	        Tourist user = (Tourist) session.getAttribute("userDetails");

	        if (user != null) {
	        	
	            int userId = user.getTid(); // Get the user ID

	            FavouritesDBUtil favDAO = new FavouritesDBUtil();  // Call DB utility to get favourite packages
	            List<TourPackage> favList = favDAO.getFavouritePackagesByUserId(userId);

	            request.setAttribute("favList", favList);  // Set list in request to forward to JSP
	            RequestDispatcher dispatcher = request.getRequestDispatcher("favList.jsp");  // Forward to the JSP page that shows favourite list
	            dispatcher.forward(request, response);
	        } else {
	        	
	            response.sendRedirect("login.jsp"); // If not logged in, redirect to login page
	        }
	}

		
		
		
}