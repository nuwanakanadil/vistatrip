package com.tripvista.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tripvista.modal.Tourist;

/**
 * Servlet implementation class ForgotPswServlet
 * 
 * This servlet handles the request to update the user's password during the "forgot password" process.
 * It validates the form inputs (username, email, and new password) and, if valid, updates the user's password.
 * If successful, it redirects the user to the login page; otherwise, it shows an error message.
 */
@WebServlet("/ForgotPswServlet")
public class ForgotPswServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		// Get input values from the forgot password form
		String userName = request.getParameter("userName");
		String email = request.getParameter("email");
		String newPassword = request.getParameter("newPassword");
		
		
		// Server-side validation
		String errorMessage = null;
		
		// Check if any field is empty
		if (userName == null || userName.isEmpty() || email == null || email.isEmpty()
				|| newPassword == null || newPassword.isEmpty()) {
			errorMessage = "All fields are required.";
		}
		// Validate email format
		else if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
			errorMessage = "Invalid email format.";
		}
		// Validate password length (at least 8 characters)
		else if (newPassword.length() < 8) {
			errorMessage = "Password must be at least 8 characters long.";
		}
		// Validate password pattern (at least one letter, one digit, and allowed special characters)
		else if (!newPassword.matches("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d@#$%^&+=]{8,}$")) {
			errorMessage = "Password must contain at least one letter, one digit, and can include special characters"
					+ " (@, #, $, %, ^, &, +, =).";
		}

		// Check for validation errors
		if (errorMessage != null) {
			HttpSession newSession = request.getSession();
			newSession.setAttribute("errorMessage", errorMessage);
            response.sendRedirect("forgotPassword.jsp");
            return;
		}
		
		// Proceed to update the password if validations pass
		Tourist tourist = new Tourist(0, null, null, userName, email, null, null, newPassword);
		
		// Call updatePassword method from the Tourist object
		boolean pswUpdate = tourist.updatePassword();
		
		if (pswUpdate) {

            // If update is successful, store a success message in session and redirect to login page
            HttpSession newSession = request.getSession();
            newSession.setAttribute("successMessage", "Password updated successfully. Please log in again.");
            response.sendRedirect("login.jsp");

        } else {
            // If update failed (user not found), store error message in session and redirect back
            HttpSession newSession = request.getSession();
            newSession.setAttribute("errorMessage", "Invalid username or email. Password update failed.");
            response.sendRedirect("forgotPassword.jsp");
        }
		

		
	}

}
