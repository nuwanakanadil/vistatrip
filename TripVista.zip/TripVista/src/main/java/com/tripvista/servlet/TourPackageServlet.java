package com.tripvista.servlet;

import com.tripvista.modal.TourPackage;
import com.tripvista.service.TourPackageService;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@WebServlet(urlPatterns = {"/tour", "/tour/"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
        maxFileSize = 1024 * 1024 * 20, // 20MB
        maxRequestSize = 1024 * 1024 * 100) // 100MB
public class TourPackageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private TourPackageService packageService;

    @Override
    public void init() throws ServletException {
        packageService = new TourPackageService();
    }

    private String handleFileUpload(Part filePart, String uploadDir) throws IOException {
        if (filePart != null && filePart.getSize() > 0) {
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            String uploadPath = getServletContext().getRealPath("") + File.separator + uploadDir;

            File dir = new File(uploadPath);
            if (!dir.exists()) dir.mkdirs();

            filePart.write(uploadPath + File.separator + fileName);
            return fileName;
        }
        return null;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            List<TourPackage> packages = packageService.getAllTourPackages();
            request.setAttribute("packages", packages);
            request.getRequestDispatcher("/admin/manage-packages.jsp").forward(request, response);
        } else if (action.equals("edit")) {
            int id = Integer.parseInt(request.getParameter("id"));
            TourPackage tourPackage = packageService.getTourPackage(id);
            request.setAttribute("tourPackage", tourPackage);
            request.getRequestDispatcher("/admin/edit-package.jsp").forward(request, response);
        } else if (action.equals("delete")) {
            int id = Integer.parseInt(request.getParameter("id"));
            packageService.deleteTourPackage(id);
            response.sendRedirect("tour");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action.equals("create")) {
            String title = request.getParameter("title");
            String description = request.getParameter("description");
            double price = Double.parseDouble(request.getParameter("price"));

            List<String> imageFileNames = new ArrayList<>();
            for (Part part : request.getParts()) {
                if (part.getName().equals("images")) {
                    String fileName = handleFileUpload(part, "tour/images");
                    if (fileName != null) imageFileNames.add(fileName);
                }
            }

            TourPackage tourPackage = new TourPackage();
            tourPackage.setTitle(title);
            tourPackage.setDescription(description);
            tourPackage.setPrice(price);
            tourPackage.setImageFileNames(imageFileNames); // You can store this as a comma-separated string

            if (packageService.createTourPackage(tourPackage, imageFielNames)) {
                response.sendRedirect("tour");
            } else {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }

        } else if (action.equals("update")) {
            int id = Integer.parseInt(request.getParameter("id"));
            String title = request.getParameter("title");
            String description = request.getParameter("description");
            double price = Double.parseDouble(request.getParameter("price"));

            List<String> newImages = new ArrayList<>();
            for (Part part : request.getParts()) {
                if (part.getName().equals("images") && part.getSize() > 0) {
                    String fileName = handleFileUpload(part, "tour/images");
                    if (fileName != null) newImages.add(fileName);
                }
            }

            TourPackage tourPackage = packageService.getPackageById(id);
            tourPackage.setTitle(title);
            tourPackage.setDescription(description);
            tourPackage.setPrice(price);
            if (!newImages.isEmpty()) {
                tourPackage.setImageFileNames(newImages); // Replace or append to existing
            }

            if (packageService.updatePackage(tourPackage)) {
                response.sendRedirect("tour");
            } else {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }
        }
    }
}

