package com.tripvista.servlet;

import com.tripvista.modal.Admin;
import com.tripvista.service.AdminService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/admin/login")
public class AdminLoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private AdminService adminService = new AdminService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Redirect if already logged in
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("admin") != null) {
        	response.sendRedirect(request.getContextPath() + "/admin");
            return;
        }

        String identifier = request.getParameter("email"); // could be email or name
        String password = request.getParameter("password");

        Admin admin = authenticateAdmin(identifier, password);

        if (admin != null) {
            // Successful login
            session = request.getSession(true);
            session.setAttribute("admin", admin);
            session.setAttribute("id", admin.getId());
            session.setAttribute("name", admin.getName());
            session.setAttribute("username", admin.getUsername());
            session.setAttribute("email", admin.getEmail());
            session.setAttribute("role", admin.getRole());
            session.setAttribute("file_name", admin.getFileName());
            session.setMaxInactiveInterval(30 * 60);
            response.sendRedirect(request.getContextPath() + "/admin");
        } else {
            // Failed login
            session = request.getSession(false);
            session.setAttribute("error", "Invalid username/email or password");
            response.sendRedirect("admin-login.jsp");
        }
    }


    private Admin authenticateAdmin(String identifier, String password) {
        for (Admin admin : adminService.getAllAdmins()) {
            if ((admin.getEmail().equalsIgnoreCase(identifier) || admin.getName().equalsIgnoreCase(identifier))
                    && admin.getPassword().equals(password)) {
                return admin;
            }
        }
        return null;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("admin") != null) {
        	response.sendRedirect(request.getContextPath() + "/admin");
        } else {
            request.getRequestDispatcher("admin-login.jsp").forward(request, response);
        }
    }
}

