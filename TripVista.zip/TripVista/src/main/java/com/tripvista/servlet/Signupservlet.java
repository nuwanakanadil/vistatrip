package com.tripvista.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tripvista.modal.Tourist;

/**
 * Servlet implementation class Signupservlet
 * 
 * This servlet handles the user signup process. It receives the user details from the signup form, 
 * performs server-side validations, and inserts the data into the database if valid. 
 * Afterward, it provides feedback to the user about the success or failure of the registration.
 */
@WebServlet("/Signupservlet")
public class Signupservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	/**
	 * Handles the HTTP POST request to process the user signup functionality.
	 * It performs validation checks on the input fields, inserts the data into the database if valid, 
	 * and redirects the user based on the result of the registration.
	 *
	 * @param request The HttpServletRequest object that contains the request data.
	 * @param response The HttpServletResponse object for sending the response.
	 * @throws ServletException If a servlet-specific error occurs.
	 * @throws IOException If an I/O error occurs.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//Get all the user entered details
		
		String fname = request.getParameter("firstName");
		String lname = request.getParameter("lastName");
		String userName = request.getParameter("username");
		String email = request.getParameter("email");
		String mobile = request.getParameter("mobile");
		String country = request.getParameter("country");
		String password = request.getParameter("password");
		
		// Server-side Validations
        String errorMessage = null;
        
        // Check if any field is empty
        if (fname.isEmpty() || lname.isEmpty() || userName.isEmpty() || email.isEmpty()
        		|| mobile.isEmpty() || country.isEmpty() || password.isEmpty()) {
            errorMessage = "All fields are required.";
        } 
        // Validate email format
        else if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            errorMessage = "Invalid email format.";
        } 
        // Validate mobile number (0-9 and length of 10 digits)
        else if (!mobile.matches("^[0-9]{10}$")) {
            errorMessage = "Invalid mobile number. It should be 10 digits.";
        } 
        // Validate password length (minimum 8 characters)
        else if (password.length() < 8) {
            errorMessage = "Password must be at least 8 characters long.";
        } 
        // Validate password pattern (at least one letter and one digit)
        else if (!password.matches("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$")) {
            errorMessage = "Password must contain at least one letter and one digit.";
        }

        // Check for validation errors
        if (errorMessage != null) {
            request.setAttribute("errorMessage", errorMessage);
            RequestDispatcher dispatcher = request.getRequestDispatcher("signup.jsp");
            dispatcher.forward(request, response);
            return;
        }
        
        
        // If validations pass, proceed to database insertion
        
        //Create a new tourist object with user entered data
        
        Tourist tourist = new Tourist(0, fname, lname, userName, email, mobile, country, password);
        
        //Call register method
        
        boolean success = tourist.register();
        
        if (success == true) {
			
        	// Success
        	//Create a session to store success message
            HttpSession session = request.getSession();
            session.setAttribute("successMessage", "Registration successful! Please log in.");
            response.sendRedirect("login.jsp");
		}else {
			
			// Failure
			//Create a session to store error message
		    HttpSession session = request.getSession();
		    session.setAttribute("errorMessage", "Registration failed. Try again.");
		    response.sendRedirect("unsuccess.jsp");
			
		}
		
		
	}

}
