package com.tripvista.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tripvista.modal.Tourist;

/**
 * Servlet implementation class UpdateUserDetailsServlet
 * This servlet handles the update of user (tourist) profile information.
 */
@WebServlet("/UpdateUserDetailsServlet")
public class UpdateUserDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

		// Retrieve the existing session; do not create a new one
        HttpSession session = request.getSession(false);
        
        // Get the user details stored in session
        Tourist user = (Tourist) session.getAttribute("userDetails");

        if (user != null) {
        	// Retrieve updated values from the request parameters
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String phone = request.getParameter("mobileNumber");
            String country = request.getParameter("country");
            

            // Update user object only if the provided values are not null or empty
            if (firstName != null && !firstName.isEmpty()) user.setFirstName(firstName);
            if (lastName != null && !lastName.isEmpty()) user.setLastName(lastName);
            if (phone != null && !phone.isEmpty()) user.setMobileNumber(phone);
            if (country != null && !country.isEmpty()) user.setCountry(country);
            

            // Call method to update details in the database
            if (user.updateUserDetails()) {
                session.setAttribute("userDetails", user); // update session object
                response.sendRedirect("dashboard.jsp?msg=updated");
                System.out.println("Your details have been successfully updated.");
            } else {
                response.sendRedirect("updateUserForm.jsp?error=updateFailed");
                System.out.println("Update failed. Please try again.");
            }
        } else {
        	// No user is logged in; redirect to login page
            response.sendRedirect("login.jsp");
            System.out.println("No logged user found");
        }
    }

}
