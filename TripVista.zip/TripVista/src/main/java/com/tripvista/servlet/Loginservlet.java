package com.tripvista.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tripvista.modal.Tourist;
import com.tripvista.util.TouristDbUtil;

/**
 * Servlet implementation class Loginservlet
 * 
 * This servlet handles the login process for the users of the system.
 * It retrieves the user's login credentials (username and password) from the login form,
 * validates them using the `Tourist` object's `login` method, and manages session data.
 * Upon successful login, it redirects the user to the homepage; if login fails, 
 * it redirects back to the login page with an error message.
 */
@WebServlet("/Loginservlet")
public class Loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {

	        // Retrieve username and password from the login form
	        String userName = request.getParameter("username"); // Match with form field name
	        String password = request.getParameter("password");

	        // Create a Tourist object using the credentials (other fields set as null)
	        Tourist tourist = new Tourist(0, null, null, userName, null, null, null, password);

	        // Call login method on the Tourist object which internally uses loginDbUtil
	        boolean loginResponse = tourist.login();

	        // If login is successful
	        if (loginResponse == true) {

	            // Create a new session and store user data
	            HttpSession session = request.getSession();
	            session.setAttribute("username", userName); // Store username in session
	            session.setAttribute("userDetails", tourist); // Store full tourist object in session
	            session.setAttribute("successMessage", "Login successful!"); // success message
	            response.sendRedirect("Home"); // Redirect to homepage after successful login

	        } else {

	            // If login fails, store error message and redirect to login page
	            HttpSession session = request.getSession();
	            session.setAttribute("errorMessage", "Invalid username or password"); // error message
	            response.sendRedirect("login.jsp"); // Redirect back to login page

	        }
	    }

}
