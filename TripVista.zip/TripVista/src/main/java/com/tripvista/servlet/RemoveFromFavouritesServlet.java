package com.tripvista.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tripvista.util.FavouritesDBUtil;

import com.tripvista.modal.Tourist;
/**
 * The RemoveFromFavouritesServlet class handles the request for removing a specific tour package from the user's favourites.
 * It retrieves the user's details from the session, calls the appropriate database utility method to remove the package from favourites,
 * and redirects the user to the Favourites page to reflect the changes.
 * If the user is not logged in, they are redirected to the login page.
 */


@WebServlet("/RemoveFromFavouritesServlet")
public class RemoveFromFavouritesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		try {
            HttpSession session = request.getSession(false); // Retrieve existing session (no new session created if it doesn't exist)
            Tourist user = (Tourist) session.getAttribute("userDetails");  // Get user details from session

            if (user != null) {
            	
                int userId = user.getTid(); // Get user ID from session
                int packageId = Integer.parseInt(request.getParameter("packageId")); // Get the package ID from request parameter
 
                FavouritesDBUtil favUtil = new FavouritesDBUtil(); // create FavouritesDBUtil object
                favUtil.removeFromFavourites(userId, packageId);   // Call removeFromFavourites method to remove the package from favourites


                response.sendRedirect("FavouritesServlet");  // Redirect to the Favourites page to reflect changes
            } else {
            	
                response.sendRedirect("login.jsp"); // If user is not logged in, redirect to login page
            }

        } catch (Exception e) {
            e.printStackTrace(); //Handle exception
           
        }
    
	}

}
