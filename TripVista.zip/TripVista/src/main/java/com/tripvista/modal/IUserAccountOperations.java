package com.tripvista.modal;

public interface IUserAccountOperations {
	
	boolean login();
	boolean register();
    boolean delete();
    boolean updatePassword();
    boolean updateUserDetails();

}
