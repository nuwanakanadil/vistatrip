package com.tripvista.modal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import com.tripvista.util.DeleteAcntDbUtil;
import com.tripvista.util.ForgotPswDbUtil;
import com.tripvista.util.UpdateTouristDbUtil;
import com.tripvista.util.LoginDbUtil;
import com.tripvista.util.TouristDbUtil;

/**
 * Tourist class represents a user in the system. It extends from the AbstractUser class and implements 
 * the IUserAccountOperations interface to handle operations like registration, login, account deletion, 
 * and password update. The class contains the necessary data fields, constructors, getter/setter methods, 
 * and the implementations for the interface methods.
 */

public class Tourist extends AbstractUser implements IUserAccountOperations {
    private int tid;
    private String firstName;
    private String lastName;
    private String mobileNumber;
    private String country;

    /**
     * Overloaded constructor to initialize a Tourist object with user data.
     *
     * @param tid The tourist ID (unique identifier).
     * @param firstName The first name of the tourist.
     * @param lastName The last name of the tourist.
     * @param username The username of the tourist.
     * @param email The email of the tourist.
     * @param mobileNumber The mobile number of the tourist.
     * @param country The country of the tourist.
     * @param password The password of the tourist.
     */
    
    public Tourist(int tid, String firstName, String lastName, String username,
    		String email, String mobileNumber, String country, String password) {
        super(username, password, email);
        this.tid = tid;
        this.firstName = firstName;
        this.lastName = lastName;
        this.mobileNumber = mobileNumber;
        this.country = country;
    }

    // Implement abstract methods
    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public String getEmail() {
        return email;
    }
    
    @Override
    public String getPassword() {
        return password;
    }

    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    
    // Getters and Setters of Tourist class

    public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	//create objects from service classes
	
	LoginDbUtil loginDB =  new LoginDbUtil();
	TouristDbUtil touristDB = new TouristDbUtil();
	DeleteAcntDbUtil dltAcntDB = new DeleteAcntDbUtil();
	ForgotPswDbUtil forgotpswDB = new ForgotPswDbUtil();
	UpdateTouristDbUtil updateTourist = new UpdateTouristDbUtil();


	// Implement interface methods
	
    @Override
    public boolean register() {   // Register new user to the system
    	
    	//Pass entire tourist object to TouristDbUtil
    	return touristDB.register(this);
    }
    
	@Override
    public boolean login() {  //Log user to the system
		
		//Pass entire tourist object to loginDbutil
		return loginDB.login(this);
	}

    @Override
    public boolean delete() {  // Delete Account from the system
    	
    	//Pass entire tourist object to dltAcntDB
    	return dltAcntDB.delete(this);
    
    }

    @Override
    public boolean updatePassword() {  // Update password of user account
    	
    	//Pass entire tourist object to forgotpswDB
    	return forgotpswDB.updatePassword(this);

    }
    
    @Override
    public boolean updateUserDetails() {  //Update user account details
    	
    	//Pass entire tourist object to updatetouristDbUtil
        return updateTourist.updateUserDetails(this);
    }
}

