package com.tripvista.modal;

public abstract class AbstractUser {
	
	protected String username;
    protected String password;
    protected String email;
    
    //Overload Constructor of AbstractUser
    public AbstractUser(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
    }
    
 // Abstract methods
    public abstract String getUsername();
    public abstract String getEmail();
    public abstract String getPassword();
    
    

}
