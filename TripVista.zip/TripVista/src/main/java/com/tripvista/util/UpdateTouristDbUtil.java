package com.tripvista.util;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.tripvista.modal.Tourist;

/**
 * Utility class for updating Tourist user details in the database.
 * 
 */
public class UpdateTouristDbUtil {
	
	 /**
     * Updates the details (first name, last name, mobile number, country) 
     * of a tourist in the database based on their unique ID (tid).
     * 
     * @param tourist The Tourist object containing updated user details.
     * @return true if the update is successful, false otherwise.
     * 
     */
	
	public boolean updateUserDetails(Tourist tourist) {
		 
		// SQL query to update user details
        String sql = "UPDATE registered_tourists SET fname = ?, lname = ?, mobileNumber = ?, country = ?"
        		+ " WHERE tid = ?";

        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set the updated values in the prepared statement
            stmt.setString(1, tourist.getFirstName());     // Set first name
            stmt.setString(2, tourist.getLastName());      // Set last name
            stmt.setString(3, tourist.getMobileNumber());  // Set mobile number
            stmt.setString(4, tourist.getCountry());       // Set country
            stmt.setInt(5, tourist.getTid());              // Set tourist ID (primary key)

            // Execute the update and check if rows were affected
            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0; // Return true if update succeeded

        } catch (Exception e) {
            e.printStackTrace(); // Print error stack trace if exception occurs
            return false;        // Return false if an error occurs
        }
}
}