package com.tripvista.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tripvista.modal.TourPackage;

public class TourPackageDBUtil {
	
	public List<TourPackage> getAllPackages() {
		
        List<TourPackage> list = new ArrayList<>();
        
        try (Connection conn = DBConnection.getConnection()){
        	
        	String sql = "SELECT * FROM tour_packages";
        	PreparedStatement stmt = conn.prepareStatement(sql);
        	ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {
        	
            TourPackage tp = new TourPackage();
            
            tp.setId(rs.getInt("id"));
            tp.setDestination(rs.getString("destination"));
            tp.setPrice(rs.getDouble("price"));
            tp.setDescription(rs.getString("description"));
            list.add(tp);
        }
       
        
    }catch (SQLException e) {
        e.printStackTrace();
    }
          return list;
        
	}
	
	public TourPackage getPackageById(int id) {
	    TourPackage tp = null;
	    String sql = "SELECT * FROM tour_packages WHERE id=?";

	    //PreparedStatement used because query has input parameters
	    
	    
	    try (Connection conn = DBConnection.getConnection();
	    		
	    	PreparedStatement  stmt = conn.prepareStatement(sql)) {

	        stmt.setInt(1, id);

	        try (ResultSet rs = stmt.executeQuery()) {
	            if (rs.next()) {
	                tp = new TourPackage();
	                tp.setId(rs.getInt("id"));
	                tp.setDestination(rs.getString("destination"));
	                tp.setPrice(rs.getDouble("price"));
	                tp.setDescription(rs.getString("description"));
	            }
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return tp;
	}
	





}
