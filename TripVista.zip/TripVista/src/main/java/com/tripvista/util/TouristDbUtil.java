package com.tripvista.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tripvista.modal.Tourist;

/**
 * The TouristDbUtil class handles database operations related to tourist accounts,
 * including user registration. It checks for duplicate usernames and passwords 
 * before inserting the user's details into the database.
 */

public class TouristDbUtil {
	
	/**
     * Hashes the password using SHA-256.
     * 
     * @param password The plain text password to hash.
     * @return The hashed password as a hexadecimal string.
     */
    private String hashPassword(String password) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = messageDigest.digest(password.getBytes());
            
            // Convert the hashed byte array into a hexadecimal string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashedBytes) {
                hexString.append(String.format("%02x", b));
            }
            
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;  // Return null if hashing fails
        }
    }
	
	/**
     * Registers a new tourist by adding their details to the database.
     * The method first checks if the username and password are unique, 
     * and if they are, it inserts the user's details into the database.
     * 
     * @param tourist The Tourist object containing the user's information.
     * @return true if registration is successful, false otherwise.
     */

    public boolean register(Tourist tourist) {
        boolean success = false;

        try (Connection conn = DBConnection.getConnection()) {  // get database connection from DbConnection class

            // First, check for duplicate username
            String checkUsernameSQL = "SELECT COUNT(*) FROM registered_tourists WHERE username = ?";
            try (PreparedStatement checkUsernameStmt = conn.prepareStatement(checkUsernameSQL)) {
                checkUsernameStmt.setString(1, tourist.getUsername());
                ResultSet rs = checkUsernameStmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    System.out.println("Username already exists");
                    throw new Exception("username_exists");
                }
            }

            // Check for duplicate password
            String checkPasswordSQL = "SELECT COUNT(*) FROM registered_tourists WHERE password = ?";
            try (PreparedStatement checkPasswordStmt = conn.prepareStatement(checkPasswordSQL)) {
            	String hashedPassword = hashPassword(tourist.getPassword());  // Hash the entered password
                checkPasswordStmt.setString(1, hashedPassword);
                ResultSet rs = checkPasswordStmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    System.out.println("Password already exists");
                    throw new Exception("password_exists");
                }
            }

            // Proceed to register user if username & password are unique
            
            // Hash the password before saving it to the database
            String hashedPassword = hashPassword(tourist.getPassword());
            if (hashedPassword == null) {
                throw new Exception("password_hashing_failed");
            }

            // Insert user entered data to the database table
            String sql = "INSERT INTO registered_tourists (fname, lname, username, email, mobileNumber, country, password)"
            		+ " VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, tourist.getFirstName());
            stmt.setString(2, tourist.getLastName());
            stmt.setString(3, tourist.getUsername());
            stmt.setString(4, tourist.getEmail());
            stmt.setString(5, tourist.getMobileNumber());
            stmt.setString(6, tourist.getCountry());
            stmt.setString(7, hashedPassword); // Store the hashed password

            int result = stmt.executeUpdate();
            if (result > 0) {
                success = true;
                System.out.println("Registration successful");
            }

        } catch (Exception e) {  // Handle exceptions
            e.printStackTrace();
        }

        return success;
    }


}