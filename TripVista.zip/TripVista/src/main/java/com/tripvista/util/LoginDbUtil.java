package com.tripvista.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.tripvista.modal.Tourist;

public class LoginDbUtil {
	/**
     * User login method
     * 
     * @param tourist The Tourist object containing user credentials
     * @return true if login is successful, false otherwise
     */
	/**
     * Hashes the password using SHA-256.
     * 
     * @param password The plain text password to hash.
     * @return The hashed password as a hexadecimal string.
     */
    private String hashPassword(String password) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = messageDigest.digest(password.getBytes());
            
            // Convert the hashed byte array into a hexadecimal string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashedBytes) {
                hexString.append(String.format("%02x", b));
            }
            
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;  // Return null if hashing fails
        }
    }
	
	public boolean login(Tourist tourist) { // User login method 
        boolean success = false;

        try (Connection conn = DBConnection.getConnection()) { // get database connection from DbConnection class
        	
        	// Hash the entered password
            String hashedPassword = hashPassword(tourist.getPassword());
            if (hashedPassword == null) {
                System.out.println("Password hashing failed");
                return false;  // If hashing fails, return false
            }
            
        	// SQL query to check if a user exists with the given username and password
            String sql = "SELECT * FROM registered_tourists WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, tourist.getUsername()); // Set username in query
            stmt.setString(2, hashedPassword); // Set password in query

            ResultSet rs = stmt.executeQuery(); // Execute query and get result set
            
            // If a match is found, populate the Tourist object with retrieved data
            if (rs.next()) {
                tourist.setTid(rs.getInt("tid"));
                tourist.setFirstName(rs.getString("fname"));
                tourist.setLastName(rs.getString("lname"));
                tourist.setEmail(rs.getString("email"));
                tourist.setMobileNumber(rs.getString("mobileNumber"));
                tourist.setCountry(rs.getString("country"));

                success = true; // Login successful
                System.out.println("Login successful");
            } else {
                System.out.println("Login failed"); // No matching user found
            }
            
         // Close result set and statement
            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace(); // Print exception if any error occurs
        }

        return success; // Return login status
    }

}
