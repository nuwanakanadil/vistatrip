package com.tripvista.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tripvista.util.DBConnection;
import com.tripvista.modal.TourPackage;

/**
 * The FavouritesDBUtil class provides utility methods to manage the user's favourite tour packages.
 * It allows adding, retrieving, and removing tour packages to/from the user's favourites in the database.
 */

public class FavouritesDBUtil {

    /**
     * Adds a specific tour package to the user's favourites.
     * If the package is already in the favourites, no error is thrown.
     * 
     * @param userId The ID of the user adding the package to favourites.
     * @param packageId The ID of the tour package to be added to favourites.
     */
    public void addToFavourites(int userId, int packageId) {
        
        // INSERT IGNORE ensures no error is thrown if the favourite already exists
        String sql = "INSERT IGNORE INTO favourites (user_id, package_id) VALUES (?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            // Set parameters for user ID and package ID
            stmt.setInt(1, userId);
            stmt.setInt(2, packageId);
            stmt.executeUpdate(); // Execute the insert statement

            System.out.println("Added to favourites successfully");

        } catch (SQLException e) { // Handle SQL Exception
            e.printStackTrace();
        }
    }

    /**
     * Retrieves a list of TourPackage objects that the user has added to their favourites.
     * 
     * @param userId The ID of the user whose favourite packages are to be retrieved.
     * @return A list of TourPackage objects that the user has marked as favourites.
     */
    public List<TourPackage> getFavouritePackagesByUserId(int userId) {
    	List<TourPackage> favPackages = new ArrayList<>();

        String sql = "SELECT tp.id, tp.destination, tp.price, tp.description " +
                     "FROM tour_packages tp " +
                     "JOIN favourites f ON tp.id = f.package_id " +
                     "WHERE f.user_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId); // Set the user ID for the query
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {  // Loop through result set and build TourPackage objects
                TourPackage tp = new TourPackage();
                tp.setId(rs.getInt("id"));
                tp.setDestination(rs.getString("destination"));
                tp.setPrice(rs.getDouble("price"));
                tp.setDescription(rs.getString("description"));

                favPackages.add(tp); // Add TourPackage objects to the ArrayList
            }

        } catch (SQLException e) { // Handle exception
            e.printStackTrace();
        }

        return favPackages;
    }

    /**
     * Removes a specific tour package from the user's favourites.
     * 
     * @param userId The ID of the user from whose favourites the package will be removed.
     * @param packageId The ID of the tour package to be removed from favourites.
     */
    public void removeFromFavourites(int userId, int packageId) {
        String sql = "DELETE FROM favourites WHERE user_id = ? AND package_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set parameters for deletion
            stmt.setInt(1, userId);
            stmt.setInt(2, packageId);
            stmt.executeUpdate(); // Execute delete statement

            System.out.println("Removed from favourites");

        } catch (SQLException e) { // Handle SQL exception
            e.printStackTrace();
        }
    }

}
