package com.tripvista.util;

import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.tripvista.util.DBConnection;
import com.tripvista.modal.Tourist;

/**
 * This class handles the deletion of a tourist's account from the database.
 */

public class DeleteAcntDbUtil {
	
	  /**
     * Hashes the password using SHA-256.
     *
     * @param password The plain text password.
     * @return The hashed password in hexadecimal format.
     * @throws Exception if hashing fails.
     */
    private String hashPassword(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = md.digest(password.getBytes("UTF-8"));

        // Convert byte array to hexadecimal string
        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1)
                hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }
	 /**
     * Deletes a tourist's account from the database.
     * 
     * @param tourist The Tourist object containing the user's credentials (username, password).
     * @return true if the account is successfully deleted, false otherwise.
     */
	
	// Method to delete a tourist account from the database
	public boolean delete(Tourist tourist) {
        boolean success = false;
        
        try (Connection conn = DBConnection.getConnection()) {
        	
        	  // Hash the password entered by the user
            String hashedPassword = hashPassword(tourist.getPassword());
        	
            // SQL statement to delete user based on username and hashed password
            String sql = "DELETE FROM registered_tourists WHERE username=? AND password=?"; 
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, tourist.getUsername()); // Set username 
            stmt.setString(2, hashedPassword); // Set password 
            int result = stmt.executeUpdate();  // Execute the query
            
            if (result > 0) {  // Check if any row was deleted
                success = true;
                System.out.println("Account deleted successfully");
            }
        } catch (Exception e) {
            e.printStackTrace(); // Print stack trace if an error occurs
        }
        return success; // Return the result of the delete operation
    }
}
