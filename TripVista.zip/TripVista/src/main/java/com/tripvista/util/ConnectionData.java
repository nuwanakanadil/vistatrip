package com.tripvista.util;

public class ConnectionData {
    public static final String DATABASE = "tripvista";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "1234";
}
