package com.tripvista.util;

import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import com.tripvista.modal.Tourist;

public class ForgotPswDbUtil {
	
	  /**
     * Hashes the password using SHA-256 algorithm.
     * 
     * @param password The plain text password.
     * @return The hashed password in hexadecimal format.
     * @throws Exception if hashing fails.
     */
    private String hashPassword(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = md.digest(password.getBytes("UTF-8"));
        
        // Convert byte array to hexadecimal string
        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }

	
	/**
     * Updates the password of a Tourist (user) after verifying their username and email.
     * The new password is hashed using SHA-256 before being stored.
     * 
     * @param tourist The Tourist object containing the user's credentials.
     * @return true if the password update is successful, false otherwise.
     */
    public boolean updatePassword(Tourist tourist) {
        boolean success = false;
        try (Connection conn = DBConnection.getConnection()) {

            // Step 1: Check if user exists
            String checkSql = "SELECT COUNT(*) FROM registered_tourists WHERE username=? AND email=?";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, tourist.getUsername());
                checkStmt.setString(2, tourist.getEmail());
                ResultSet rs = checkStmt.executeQuery();

                if (rs.next() && rs.getInt(1) > 0) {
                    // Step 2: Hash the new password
                    String hashedPassword = hashPassword(tourist.getPassword());

                    // Step 3: Update password
                    String updateSql = "UPDATE registered_tourists SET password=? WHERE username=? AND email=?";
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                        updateStmt.setString(1, hashedPassword);
                        updateStmt.setString(2, tourist.getUsername());
                        updateStmt.setString(3, tourist.getEmail());
                        int result = updateStmt.executeUpdate();

                        if (result > 0) {
                            success = true;
                            System.out.println("Password updated successfully (hashed).");
                        }
                    }
                } else {
                    System.out.println("No matching user found. Prompt sign-up.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }

  

}